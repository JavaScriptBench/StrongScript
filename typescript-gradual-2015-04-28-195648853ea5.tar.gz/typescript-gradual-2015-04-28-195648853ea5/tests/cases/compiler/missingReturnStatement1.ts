class Foo {
    foo(): number {
        //return 4;
    }
}
