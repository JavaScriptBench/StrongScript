function boo {
  static test()
  static test(name:string)
  static test(name?:any){ }
}