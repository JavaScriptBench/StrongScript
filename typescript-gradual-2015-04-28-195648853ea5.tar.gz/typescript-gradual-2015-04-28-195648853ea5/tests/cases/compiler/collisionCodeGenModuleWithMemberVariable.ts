module m1 {
    export var m1 = 10;
    var b = m1;
}
var foo = m1.m1;