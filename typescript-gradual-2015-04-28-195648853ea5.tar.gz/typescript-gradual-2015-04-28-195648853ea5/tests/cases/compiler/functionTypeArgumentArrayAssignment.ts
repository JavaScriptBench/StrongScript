module test {
    interface Array<T> {
        foo: T;
        length: number;
    }

    function map<U>() {
        var ys: U[] = [];
    }
}
