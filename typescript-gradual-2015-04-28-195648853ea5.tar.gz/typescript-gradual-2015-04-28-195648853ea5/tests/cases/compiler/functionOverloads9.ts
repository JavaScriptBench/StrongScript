function foo(foo:string);
function foo(foo?:string){ return '' };
var x = foo('foo');
