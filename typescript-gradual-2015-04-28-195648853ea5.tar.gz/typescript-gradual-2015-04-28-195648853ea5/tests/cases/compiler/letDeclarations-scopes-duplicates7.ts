// @target: ES6

// @Filename: file1.ts
let var1 = 0;

// @Filename: file2.ts
var var1 = 0;