enum Position { 
    IgnoreRulesSpecific = 0,
}
var x = IgnoreRulesSpecific.
var y = Position.IgnoreRulesSpecific;
