target:
while (true) {
  target:
  while (true) {
  }
}