target:
while (true) {
  break target;
}