class C {
    
}

class D<T> extends C {
    constructor() {
        super<T>();
    }
}