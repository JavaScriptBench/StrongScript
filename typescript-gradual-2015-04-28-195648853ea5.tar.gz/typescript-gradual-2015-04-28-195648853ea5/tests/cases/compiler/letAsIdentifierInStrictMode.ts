"use strict";
var let = 10;
var a = 10;
let = 30;
let
a;