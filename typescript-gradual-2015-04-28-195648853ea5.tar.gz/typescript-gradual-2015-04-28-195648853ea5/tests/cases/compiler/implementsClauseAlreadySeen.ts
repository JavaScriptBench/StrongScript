class C {
    
}
class D implements C implements C {
    baz() { }
}