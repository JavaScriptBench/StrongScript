class _this {
}
var f = () => this;