class Test1 {
  "prop1" = 0;
}