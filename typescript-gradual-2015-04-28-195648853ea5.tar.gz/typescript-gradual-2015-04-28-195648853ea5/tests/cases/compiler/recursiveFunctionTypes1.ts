class C {
     static g(t: typeof C.g){ }
}