class A {
    a(completed: () => any): void;
}
