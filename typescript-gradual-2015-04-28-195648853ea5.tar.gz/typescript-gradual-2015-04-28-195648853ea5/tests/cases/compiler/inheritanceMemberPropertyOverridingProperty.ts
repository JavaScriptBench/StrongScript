class a {
    x: () => string;
}

class b extends a {
    x: () => string;
}