// @target: ES3
// @sourcemap: false
// @declaration: false
// @module: amd

class A
{
    constructor ()
    {

    }

    public B()
    {
        return 42;
    }
}