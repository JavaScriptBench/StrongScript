//@module: commonjs
//@declaration: true
function foo() {
}
export var x: typeof foo;
export var b = foo;
