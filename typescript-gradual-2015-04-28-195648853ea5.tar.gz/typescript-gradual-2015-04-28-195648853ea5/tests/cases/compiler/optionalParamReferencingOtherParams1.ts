function strange(x: number, y = x * 1, z = x + y) {
    return z;
}