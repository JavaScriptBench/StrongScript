class foo<T> {
    static P: T;
} 