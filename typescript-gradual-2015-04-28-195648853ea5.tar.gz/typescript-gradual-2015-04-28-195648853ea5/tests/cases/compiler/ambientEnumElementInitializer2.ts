declare enum E {
 e = -3 // Negative
}