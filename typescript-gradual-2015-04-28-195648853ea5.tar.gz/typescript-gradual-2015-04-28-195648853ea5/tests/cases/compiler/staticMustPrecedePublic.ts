class Outer {
    static public intI: number;
    static private stringF: string;
}
