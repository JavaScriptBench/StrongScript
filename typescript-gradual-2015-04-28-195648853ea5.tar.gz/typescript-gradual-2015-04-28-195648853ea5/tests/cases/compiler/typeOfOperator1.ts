var x = 1;
var y: string = typeof x;
var z: number = typeof x;