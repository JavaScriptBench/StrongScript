interface IFoo { }

interface IBar implements IFoo {
}