// @declaration: true

module M { export var x; }
var m = M;