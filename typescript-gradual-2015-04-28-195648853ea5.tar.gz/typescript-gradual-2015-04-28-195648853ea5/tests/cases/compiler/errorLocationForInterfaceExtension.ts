var n = '';

interface x extends string { }
