// @target: ES5

const z7 = false;
const z8: number = 23;
const z9 = 0, z10 :string = "", z11 = null;
