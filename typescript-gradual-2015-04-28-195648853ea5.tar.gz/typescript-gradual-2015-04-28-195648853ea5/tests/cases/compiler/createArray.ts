var na=new number[];

class C {
}

new C[];
var ba=new boolean[];
var sa=new string[];
function f(s:string):number { return 0;
}
if (ba[14]) {
    na[2]=f(sa[3]);
}

new C[1]; // not an error