1..toString();
1.0.toString();
1.toString();
1.+2.0 + 3. ;