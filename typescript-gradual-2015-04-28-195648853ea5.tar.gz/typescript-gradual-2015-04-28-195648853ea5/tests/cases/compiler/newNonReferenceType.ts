var a = new any();
var b = new boolean(); // error
