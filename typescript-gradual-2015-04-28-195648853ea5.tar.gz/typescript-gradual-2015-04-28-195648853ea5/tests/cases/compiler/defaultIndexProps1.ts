class Foo {
	public v = "Yo";
}

var f = new Foo();

var q = f["v"];

var o = {v:"Yo2"};

var q2 = o["v"];
