module M {
    () => 0;
}