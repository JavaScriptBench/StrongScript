// All should be allowed
function f(): any { }
var f2: () => any = () => { };
var f3 = (): any => { };