// @target: ES3
// @sourcemap: true
// @declaration: false
// @module: commonjs