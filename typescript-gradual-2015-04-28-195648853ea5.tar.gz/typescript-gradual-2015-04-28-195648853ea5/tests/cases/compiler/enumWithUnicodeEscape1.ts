enum E {
  'gold \u2730'
}
