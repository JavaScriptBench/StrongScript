// Invalid code gen for Array of Module class

module M
{
    export class A { }
    class B{ }
}

var t: M.A[] = [];
var t2: M.B[] = [];