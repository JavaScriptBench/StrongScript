module M {

export class C<T> { }

}
 
var x = new M.C<string>();
