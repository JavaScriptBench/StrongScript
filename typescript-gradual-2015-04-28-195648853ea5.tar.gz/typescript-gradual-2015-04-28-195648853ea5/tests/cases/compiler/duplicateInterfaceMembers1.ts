interface Bar {
   x: number;
   x: number;
}
