module 'M' {}

declare module 'M2' {}