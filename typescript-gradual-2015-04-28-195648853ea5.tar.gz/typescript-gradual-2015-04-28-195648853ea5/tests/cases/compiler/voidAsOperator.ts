if (!void 0 !== true) {
 
}

//CHECK#2
if (!null !== true) {
 
}
