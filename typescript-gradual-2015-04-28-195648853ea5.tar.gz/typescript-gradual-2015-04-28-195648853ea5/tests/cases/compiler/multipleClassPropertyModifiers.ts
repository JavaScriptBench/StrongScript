class C {
    public static p1;
    static public p2;
    private static p3;
    static private p4;
}