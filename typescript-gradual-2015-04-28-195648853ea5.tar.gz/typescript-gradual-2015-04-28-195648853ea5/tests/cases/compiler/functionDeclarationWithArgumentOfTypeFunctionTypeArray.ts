// @declaration: true
function foo(args: { (x): number }[]) {
    return args.length;
}
