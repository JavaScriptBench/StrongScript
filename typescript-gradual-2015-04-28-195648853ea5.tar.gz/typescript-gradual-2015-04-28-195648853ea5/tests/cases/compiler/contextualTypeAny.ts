var x: any;

var obj: { [s: string]: number } = { p: "", q: x };

var arr: number[] = ["", x];