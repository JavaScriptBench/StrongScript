var s: string[];
var n: number[];

s = n;