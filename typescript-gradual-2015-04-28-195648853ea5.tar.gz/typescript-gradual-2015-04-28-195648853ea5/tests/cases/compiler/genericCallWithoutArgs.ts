function f<X, Y>(x: X, y: Y) {
}

f<number,string>.