interface A {
    0: string;
}
var x: A = {
    0: 3
};
