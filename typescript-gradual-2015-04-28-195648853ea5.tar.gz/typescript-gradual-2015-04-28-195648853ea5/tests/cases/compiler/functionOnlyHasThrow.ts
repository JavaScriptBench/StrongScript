function clone():number {
	throw new Error("To be implemented");
}