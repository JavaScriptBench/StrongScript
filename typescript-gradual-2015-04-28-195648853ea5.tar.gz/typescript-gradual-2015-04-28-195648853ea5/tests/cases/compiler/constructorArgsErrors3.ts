class foo {
    constructor (public public a: number) {
    }
}
