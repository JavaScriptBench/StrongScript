var tt = { aa; }
var x = tt;