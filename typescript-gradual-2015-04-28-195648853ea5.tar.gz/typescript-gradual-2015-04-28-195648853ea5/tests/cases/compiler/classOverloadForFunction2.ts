function bar(): string;
class bar {}