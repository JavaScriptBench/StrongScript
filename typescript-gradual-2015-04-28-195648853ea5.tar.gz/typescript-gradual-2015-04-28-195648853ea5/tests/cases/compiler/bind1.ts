module M {
    export class C implements I {} // this should be an unresolved symbol I error
}

