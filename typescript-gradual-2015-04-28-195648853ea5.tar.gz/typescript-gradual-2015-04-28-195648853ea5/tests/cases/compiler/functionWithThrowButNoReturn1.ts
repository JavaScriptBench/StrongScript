function fn(): number {
  throw new Error('NYI');
  var t;
}
