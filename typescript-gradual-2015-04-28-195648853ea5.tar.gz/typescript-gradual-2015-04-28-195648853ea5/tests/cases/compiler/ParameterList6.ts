class C {
  constructor(C: (public A) => any) {
  }
}