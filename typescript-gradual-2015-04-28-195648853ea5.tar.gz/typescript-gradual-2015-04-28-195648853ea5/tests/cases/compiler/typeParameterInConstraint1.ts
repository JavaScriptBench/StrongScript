class C<T, U extends T> {
}