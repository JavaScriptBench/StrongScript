class a {
    x() {
        return "20";
    }
}

class b extends a {
    x: () => string;
}