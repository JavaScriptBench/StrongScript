if (0) {
} else if (1) {
} else if (2) {
} else if (3) {
} else {
}