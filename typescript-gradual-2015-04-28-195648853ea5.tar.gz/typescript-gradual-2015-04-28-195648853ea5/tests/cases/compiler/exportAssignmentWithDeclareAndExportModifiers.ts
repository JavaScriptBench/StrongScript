﻿// @module: commonjs
var x;
export declare export = x;