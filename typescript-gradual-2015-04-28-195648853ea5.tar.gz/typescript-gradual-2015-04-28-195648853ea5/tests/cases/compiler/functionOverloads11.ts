function foo():number;
function foo():string { return "" }
