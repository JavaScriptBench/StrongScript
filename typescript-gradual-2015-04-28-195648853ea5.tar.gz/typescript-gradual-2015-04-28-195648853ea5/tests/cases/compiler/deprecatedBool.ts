var b4: boolean;
var bool: boolean;
