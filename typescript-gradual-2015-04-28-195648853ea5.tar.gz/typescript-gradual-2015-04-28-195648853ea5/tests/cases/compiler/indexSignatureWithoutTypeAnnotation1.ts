class C {
  [a: number];
}