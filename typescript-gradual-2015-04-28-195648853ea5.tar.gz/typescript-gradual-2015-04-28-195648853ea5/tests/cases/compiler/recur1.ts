var salt:any = new salt.pepper();   
salt.pepper = function() {}

var cobalt = new cobalt.pitch();   
cobalt.pitch = function() {}
 
