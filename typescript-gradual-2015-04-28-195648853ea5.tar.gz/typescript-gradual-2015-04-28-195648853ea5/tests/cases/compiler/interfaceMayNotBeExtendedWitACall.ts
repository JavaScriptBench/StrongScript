interface color {}

interface blue extends color() { // error

}
