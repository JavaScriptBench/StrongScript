target:
while (true) {
  function f() {
    while (true) {
      break target;
    }
  }
}