function f() {
    var x=arguments[12];
}