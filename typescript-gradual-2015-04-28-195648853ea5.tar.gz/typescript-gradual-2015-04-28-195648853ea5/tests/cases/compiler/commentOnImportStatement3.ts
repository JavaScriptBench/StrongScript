//@module: commonjs
// @comments: true
/* copyright */

/* not copyright */
import foo = require('./foo');