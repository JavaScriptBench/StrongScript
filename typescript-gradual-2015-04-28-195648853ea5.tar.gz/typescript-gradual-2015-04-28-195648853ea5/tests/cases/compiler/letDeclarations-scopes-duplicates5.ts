// @target: ES6

// @Filename: file1.ts
const var1 = 0;

// @Filename: file2.ts
const var1 = 0;