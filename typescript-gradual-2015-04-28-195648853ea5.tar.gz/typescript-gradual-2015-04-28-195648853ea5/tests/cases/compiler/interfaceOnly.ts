// @declaration: true
interface foo {
    foo();
    f2 (f: ()=> void);
}