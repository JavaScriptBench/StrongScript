class a {
    static x: a;
}

class b extends a {
    static x: b;
}