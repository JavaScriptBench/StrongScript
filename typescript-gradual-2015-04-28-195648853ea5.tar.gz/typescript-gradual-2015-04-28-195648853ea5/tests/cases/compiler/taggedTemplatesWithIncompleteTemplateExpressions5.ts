﻿// @target: es6

function f(x: TemplateStringsArray, y: string, z: string) {
}

// Incomplete call, but too many parameters.
f `123qdawdrqw${ 1 }${ 2 }${ 