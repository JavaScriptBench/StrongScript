//@module: commonjs
export class Foo {
}

export var foo = new Foo();

export function test(foo: Foo) {
    return true;
}
