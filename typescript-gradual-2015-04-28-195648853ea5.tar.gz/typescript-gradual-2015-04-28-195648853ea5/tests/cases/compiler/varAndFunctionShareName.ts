var myFn;
function myFn(): any { }