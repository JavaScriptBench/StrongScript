class I<T> {}
var x: I<>;