class List {
  public Blah() {
    this.Foo();
  }
  public static Foo() {}
}