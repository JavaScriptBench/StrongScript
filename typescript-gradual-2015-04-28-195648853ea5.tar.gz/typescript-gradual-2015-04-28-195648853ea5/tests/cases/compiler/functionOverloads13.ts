function foo(bar:number):string;
function foo(bar:number):number;
function foo(bar?:number):any { return "" }
