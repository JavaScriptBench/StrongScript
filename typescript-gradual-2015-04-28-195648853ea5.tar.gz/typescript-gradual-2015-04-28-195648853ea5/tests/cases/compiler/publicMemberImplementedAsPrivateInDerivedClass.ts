interface Qux {
 Bar: number;
}
class Foo implements Qux {
 private Bar: number;
}
