class C<T> {
    constructor(x: T);
    constructor(x: T);
    constructor(x: any) { }
}