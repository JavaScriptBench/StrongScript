class C<T> {
    x: T;
}

C.prototype.x.boo; // No error, prototype is instantiated to any