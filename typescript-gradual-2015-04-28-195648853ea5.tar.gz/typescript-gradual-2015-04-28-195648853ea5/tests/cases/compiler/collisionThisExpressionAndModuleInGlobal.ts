module _this { //Error
    class c {
    }
}
var f = () => this;