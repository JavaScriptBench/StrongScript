do {
  break;
}
while (true);