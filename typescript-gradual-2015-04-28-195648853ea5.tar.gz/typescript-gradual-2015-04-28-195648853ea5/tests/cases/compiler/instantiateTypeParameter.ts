interface Foo<T> {
    var x: T<>;
}