var console: {
    log(val: any);
}
function x() {
    var _this = 5;
    x => { console.log(this.x); };
}