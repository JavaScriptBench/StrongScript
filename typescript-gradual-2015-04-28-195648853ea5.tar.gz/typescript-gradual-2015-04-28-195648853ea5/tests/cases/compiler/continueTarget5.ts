target:
while (true) {
  function f() {
    while (true) {
      continue target;
    }
  }
}