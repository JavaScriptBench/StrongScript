declare class foo{};
function foo() { return null; }
