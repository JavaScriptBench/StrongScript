var Markup;

class Markup {
    constructor() {
    }
}
