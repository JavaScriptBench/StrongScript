module E {
    var t;
}
enum E { }

enum F { }
module F { var t; }

module A {
    var o;
}
enum A {
    b
}
enum A {
    c
}
module A {
    var p;
}