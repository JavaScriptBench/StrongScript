//@module: amd
import foo = m1;
 
export module m1 { }
 
class foo { }
