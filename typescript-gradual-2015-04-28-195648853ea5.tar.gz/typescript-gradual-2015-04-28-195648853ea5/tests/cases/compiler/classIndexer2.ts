class C123 {
    [s: string]: number;
    x: number;
    y: string;
    constructor() {
    }
}