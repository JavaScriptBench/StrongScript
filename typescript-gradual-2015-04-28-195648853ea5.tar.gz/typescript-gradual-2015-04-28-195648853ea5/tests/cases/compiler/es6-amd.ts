// @target: ES6
// @sourcemap: false
// @declaration: false
// @module: amd

class A
{
    constructor ()
    {

    }

    public B()
    {
        return 42;
    }
}