class a {
    static x: string;
}

class b extends a {
    static x() {
        return "20";
    }
}