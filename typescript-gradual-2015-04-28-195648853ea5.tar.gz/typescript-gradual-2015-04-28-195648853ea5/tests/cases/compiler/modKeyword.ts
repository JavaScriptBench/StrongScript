var module:any;
var foo:any;

var _ = module.exports = foo