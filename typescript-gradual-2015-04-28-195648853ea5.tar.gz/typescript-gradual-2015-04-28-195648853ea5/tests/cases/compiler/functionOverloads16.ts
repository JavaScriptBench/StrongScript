function foo(foo:{a:string;}):string;
function foo(foo:{a:string;}):number;
function foo(foo:{a:string; b?:number;}):any { return "" }
