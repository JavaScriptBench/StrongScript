function foo(x: string = '');
function foo(x = '') { }