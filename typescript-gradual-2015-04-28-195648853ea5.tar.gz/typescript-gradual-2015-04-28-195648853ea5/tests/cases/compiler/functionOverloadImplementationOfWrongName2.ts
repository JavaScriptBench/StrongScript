function foo(x);
function bar() { }
function foo(x, y);