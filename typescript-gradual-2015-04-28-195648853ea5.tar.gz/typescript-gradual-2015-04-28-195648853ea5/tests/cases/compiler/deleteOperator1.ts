var a;
var x: boolean = delete a;
var y: any = delete a;
var z: number = delete a;