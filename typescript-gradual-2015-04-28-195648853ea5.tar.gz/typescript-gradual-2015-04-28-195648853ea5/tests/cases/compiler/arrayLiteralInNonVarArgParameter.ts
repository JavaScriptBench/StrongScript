function panic(val: string[], ...opt: string[]) { }

panic([], 'one', 'two');
