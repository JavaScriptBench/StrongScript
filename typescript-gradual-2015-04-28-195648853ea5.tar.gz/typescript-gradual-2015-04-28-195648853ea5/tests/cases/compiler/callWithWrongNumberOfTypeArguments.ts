function f<T, U>() { }

f<number>();
f<number, string>();
f<number, string, number>();