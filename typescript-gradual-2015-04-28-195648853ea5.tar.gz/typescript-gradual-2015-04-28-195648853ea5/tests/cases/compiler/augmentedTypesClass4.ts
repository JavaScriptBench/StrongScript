//// class then class
class c3 { public foo() { } } // error
class c3 { public bar() { } } // error
