declare module foo {
    export function x(): any;
}
class foo { } // Legal, because module is ambient