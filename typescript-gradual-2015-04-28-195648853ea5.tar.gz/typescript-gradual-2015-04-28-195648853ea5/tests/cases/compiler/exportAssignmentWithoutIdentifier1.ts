//@module: commonjs
function Greeter() {
    //...
}
Greeter.prototype.greet = function () {
    //...
}
export = new Greeter();
