var foo: any;
foo.bar = 4;