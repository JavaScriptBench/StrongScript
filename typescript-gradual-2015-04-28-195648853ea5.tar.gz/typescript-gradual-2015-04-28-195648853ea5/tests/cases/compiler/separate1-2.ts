module X {
    export function f() { }
}