// @target: es5

class C {
    set X(public v) { }
    static set X(public v2) { }
}