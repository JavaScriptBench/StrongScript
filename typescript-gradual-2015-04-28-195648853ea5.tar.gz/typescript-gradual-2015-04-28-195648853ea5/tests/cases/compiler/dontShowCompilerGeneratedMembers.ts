var f: {
    x: number;
    <-
};