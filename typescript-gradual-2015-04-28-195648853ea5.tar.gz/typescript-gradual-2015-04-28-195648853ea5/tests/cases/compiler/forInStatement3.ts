function F<T>() {
  var expr: T;
  for (var a in expr) {
  }
}