function foo(x);
function foo(x, y);
function bar() { }