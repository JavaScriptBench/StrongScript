// RegExpExecArray.slice can have zero, one, or two arguments
var regExpExecArrayValue: RegExpExecArray;
regExpExecArrayValue.slice();
regExpExecArrayValue.slice(0);
regExpExecArrayValue.slice(0,1);