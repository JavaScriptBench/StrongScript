class Test1 {
  static "prop1" = 0;
}